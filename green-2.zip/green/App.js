import React from 'react';
import { Text, View, StyleSheet, Image, FlatList, TextInput, Alert } from 'react-native';
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import {createStackNavigator, createAppContainer} from 'react-navigation';
import Constants from 'expo-constants';
import { createMaterialBottomTabNavigator } from "react-navigation-material-bottom-tabs";

Welcomescreen = createStackNavigator({
  Welcome : { screen: () => <Loging /> },
  MainApp : { screen: () => <Container />}
},
{  
  initialRouteName: "Welcome",
})

ContainerApp = createAppContainer(Welcomescreen);

Navigation = createMaterialBottomTabNavigator({
  Home: { screen: () => <Home />,  
    navigationOptions:{  
        tabBarLabel:'Home',  
        tabBarIcon: ({ tintColor }) => (  
            <View>  
                <Icon style={[{color: tintColor}]} size={25} name={'home'}/>  
            </View>)
    }
  },
  Scan: { screen: () => <Scan />,  
    navigationOptions:{  
        tabBarLabel:'Scan',  
        tabBarIcon: ({ tintColor }) => (  
            <View>  
                <Icon style={[{color: tintColor}]} size={25} name={'camera'}/>  
            </View>)  
    }
  } ,

  Account: { screen: () => <Account />,  
    navigationOptions:{  
        tabBarLabel:'Account',  
        tabBarIcon: ({ tintColor }) => (  
            <View>  
                <Icon style={[{color: tintColor}]} size={25} name={'user'}/>  
            </View>) 
    } , 
}}, {  
  initialRouteName: "Home",  
  activeColor: '#f0edf6',  
  inactiveColor: '#226557',  
  barStyle: { backgroundColor: '#3BAD87' },  
},  );

class Loging extends React.Component {
  render() {
    return (
      <View style={{
        justifyContent:'center',
        alignItems: 'center',
      }}>
        <Image source={require('./assets/logo.jpg')} style={{width: 300, height: 300}}>
        </Image>
        <Text style={{fontSize: 25, color: 'green'}}>Stop Plastic. Go Green
        </Text>
      </View>
    );
  }
}

class NagavitationTop extends React.Component {
  render() {
    return (
      <View style={{justifyContent: 'center', alignContent: 'center'}}><Image source={require('./assets/logo.jpg')} style={{width: 60, height: 60, alignSelf:'center'}}></Image></View>
    )
  }
}

class NagavitationBottom extends React.Component {
  render() {
    return (
      <View style={{flexDirection: 'row', justifyContent:'space-between', alignItems: 'center', backgroundColor: 'white', padding: 10}}>
        <View><Icon reverse name='home' size={60} /></View>
        <View><Icon reverse name='camera-retro' size={60} /></View>
        <View><Icon reverse name='user-circle' size={60} /></View>
      </View>
    );
  }
}

class Home extends React.Component {
  constructor(props){
    super(props);
    this.state ={
      Thongbao: ["ROYALTEA 25 Lò Đúc tặng bạn thêm 5 GreenLeaves ", "thongbao2","thongbao3","thongbao4","thongbao5"], 
      Ten: [{ten : "Mot", diem: 480}, {ten: "Hai", diem: 500}, {ten: "Ba", diem: 400}]
    };
  }
  render() {
    return (
      <View>
        <View style={{
        justifyContent:'center',
        alignItems: 'center',
        }}>
          <Text style={{fontSize: 20}}>Chào Linh!</Text>
          <Text style={{fontSize: 15}}>Bạn đã sẵn sàng gieo trồng hạt chưa?</Text>
        </View>
        <View style={{ backgroundColor: 'lightgreen',flex:1, flexDirection: 'row'}}>
          <View>
            <Image source={require('./assets/logo.jpg')} style={{width: 40, height: 40}}></Image>
          </View>
          <View>
            <Text style={{fontSize: 20, color:'green'}}>Lucky News</Text>
          </View>
        </View>
        <View style={{
        justifyContent:'center',
        alignItems: 'center',
        }}>
          <Text></Text><Text></Text>
          <FlatList data={this.state.Thongbao} renderItem = {({item}) => {
            return (
              <View style={{flex:1, flexDirection: 'row'}}>
              <View >
                <Image source={require('./assets/logo.jpg')} style={{width: 40, height: 40}}></Image>
              </View>
              <View>
                <Text style={{fontSize: 15,color:'green'}}>{item}</Text>
              </View>
              </View>
              ); 
            }}>
          </FlatList>
        </View>
        <View>
          <View style={{
        justifyContent:'center',
        alignItems: 'center',
        backgroundColor: 'lightgreen'
        }}>
            <Text style={{fontSize: 20, color:'green'}}>Bảng xếp hạng</Text>
          </View>
          <View style={{
        justifyContent:'center',
        alignItems: 'center',
        }}>
          <Text>Ten Diem</Text>
          <FlatList data={this.state.Ten} renderItem = {({item}) => {
            return (
              <View style={{flex:1, flexDirection: 'row'}}>
              <View >
                <Image source={require('./assets/logo.jpg')} style={{width: 40, height: 40}}></Image>
              </View>
              <View>
                <Text style={{fontSize: 15,color:'green'}}>{item.ten} {item.diem}</Text>
              </View>
              </View>
              ); 
            }}>
          </FlatList>
        </View>
        </View>
      </View>
    );
  }
}

class Account extends React.Component {
  constructor(props){
    super(props);
    this.state ={
      Option: ["1000 green leaves", "Chỉnh sửa thông tin","Phần thưởng","Quản lí cốc", "Cài đặt ứng dụng", "Mời bạn bè", "Trợ giúp"]
    };
  }
  render() {
    return(
      <View>
        <View style={{flex:1, flexDirection: 'row', paddingTop: Constants.statusBarHeight}}>
          <View >
            <Text style={{fontSize: 20,color:'green'}}>        Tài khoản                     </Text>
          </View>
          <View >
            <Image source={require('./assets/logo.jpg')} style={{width: 20, height: 20}}></Image>
          </View>
          <View>
            <Text style={{fontSize: 20,color:'green'}}>Rank:</Text>
            <Text></Text>
          </View>
        </View>
        <View style={{
        justifyContent:'center',
        alignItems: 'center',
        paddingTop: Constants.statusBarHeight
        }}>
          <FlatList data={this.state.Option} renderItem = {({item}) => {
            return (
              <View style={{flex:1, flexDirection: 'row'}}>
                <View >
                  <Image source={require('./assets/logo.jpg')} style={{width: 40, height: 40}}></Image>
                </View>
                <View>
                  <Text style={{fontSize: 20}}>{item}</Text>
                </View>
              </View>
              ); 
            }}>
          </FlatList>
        </View>
      </View>
    );
  }
}

class Scan extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      input: ''
    };
  }

  handleOnPress = (event) => {
    event.preventDefault();
    Alert.alert("Nhập mã thành công", "Cảm ơn bạn đã bảo vệ môi trường. Rank mới của bạn là: 999");
    this.setState({input: ''})
  }

  render(){

    return(
      <View style={{justifyContent:'center', alignItems: 'center'}}>
        <TextInput
          style={{height: 40}}
          placeholder="Type Code Here"
          onChangeText={(text) => this.setState({input: text})}
          value={this.state.input}
        />
        <Button title="Claim" onPress={this.handleOnPress} />
      </View>
    );
  }
}

class Confirmed extends React.Component {
  render(){
    return(
      <View>
        <View style={{
          justifyContent:'center',
          alignItems: 'center',
          backgroundColor: 'grey'}}>
          <Text style={{fontSize: 30, color: 'lightyellow'}}>Confirmed</Text>
        </View>
        <View style={{
          justifyContent:'center',
          alignItems: 'center',
          paddingTop: Constants.statusBarHeight}}>
          <Text style={{fontSize: 50, color: 'grey'}}>SUCCESS!</Text>
          <Text></Text>
        </View>
        <View style={{
          justifyContent:'center',
          alignItems: 'center',
          paddingTop: Constants.statusBarHeight,
          backgroundColor: 'lightgreen'}}>
          <Text style={{fontSize: 35, color: 'lightyellow'}}>+5</Text>
          <Text style={{fontSize: 35, color: 'lightyellow'}}>GREEN LEAVES</Text>
        </View>
        <View style={{
          justifyContent:'center',
          alignItems: 'center',
          paddingTop: Constants.statusBarHeight}}>
          <Image source={require('./assets/logo.jpg')} style={{width: 40, height: 40}}></Image>
          <Text style={{fontSize: 35}}>Cảm ơn bạn </Text>
          <Text style={{fontSize: 35}}>đã bảo vệ môi trường!</Text>
          <Text></Text><Text></Text><Text></Text>
        </View>
        <View style={{
          justifyContent:'center',
          alignItems: 'center',
          backgroundColor: 'lightgreen'}}>
          <Text style={{fontSize: 30, color: 'lightyellow'}}>Xếp hạng mới: </Text>
        </View>
      </View>
    );
  }
}

Container = createAppContainer(Navigation);  

export default class App extends React.Component {
  render() {
    return (
      <View style={{paddingTop: Constants.statusBarHeight, flex: 1}}>
        <ContainerApp />
      </View>
    );
  }
}

//        <View style={{flex:1}} ><NagavitationTop /></View>
//        <View style={{flex: 10}} ><Account /></View>
//        <View style={{flex:1}} ></View>
//        <NagavitationBottom />

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
